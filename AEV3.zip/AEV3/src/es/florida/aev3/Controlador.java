package es.florida.aev3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import es.florida.aev3.Modelo;
import es.florida.aev3.Vista;

public class Controlador {
	private Modelo modelo;
	private Vista vista;
	private ActionListener actionListener_CrearRegistre;
	
	Controlador(Modelo m, Vista v){
		this.modelo=m;
		this.vista=v;
		control();
	}
	
	public void control() {
		
		actionListener_CrearRegistre = new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				modelo.crearBook(Integer.parseInt(vista.getTxtId().getText()), vista.getTxtTitle().getText(), vista.getTxtAuthor().getText(), Integer.parseInt(vista.getTxtAnyNax().getText()), Integer.parseInt(vista.getTxtAnyPub().getText()), vista.getTxtEditorial().getText(), Integer.parseInt(vista.getTxtNumPag().getText()), "");
			}
		};
		vista.getBtnCrear().addActionListener(actionListener_CrearRegistre);
	}
}
