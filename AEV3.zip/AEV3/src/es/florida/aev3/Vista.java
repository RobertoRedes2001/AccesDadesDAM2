package es.florida.aev3;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Vista extends JFrame {
	
	//Declarar interfaz
	private JPanel contentPane;
	private JTextField txtAnyNax;
	private JTextField txtAnyPub;
	private JTextField txtEditorial;
	private JTextField txtAuthor;
	private JTextField txtTitle;
	private JTextField txtId;
	private JTextField txtNumPag;
	private JButton btnCrear;

	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 897, 480);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl_AnyNax = new JLabel("Any de Naiximent:");
		lbl_AnyNax.setBounds(535, 150, 103, 20);
		contentPane.add(lbl_AnyNax);
		
		txtAnyNax = new JTextField();
		txtAnyNax.setBounds(648, 150, 86, 20);
		contentPane.add(txtAnyNax);
		txtAnyNax.setColumns(10);
		
		txtAnyPub = new JTextField();
		txtAnyPub.setColumns(10);
		txtAnyPub.setBounds(648, 179, 86, 20);
		contentPane.add(txtAnyPub);
		
		JLabel lbl_AnyPub = new JLabel("Any de Publicaci\u00F3:");
		lbl_AnyPub.setBounds(535, 179, 103, 20);
		contentPane.add(lbl_AnyPub);
		
		txtEditorial = new JTextField();
		txtEditorial.setColumns(10);
		txtEditorial.setBounds(594, 210, 86, 20);
		contentPane.add(txtEditorial);
		
		JLabel lbl_Editorial = new JLabel("Editorial:");
		lbl_Editorial.setBounds(535, 210, 67, 20);
		contentPane.add(lbl_Editorial);
		
		txtAuthor = new JTextField();
		txtAuthor.setColumns(10);
		txtAuthor.setBounds(580, 119, 86, 20);
		contentPane.add(txtAuthor);
		
		JLabel lbl_Author = new JLabel("Autor:");
		lbl_Author.setBounds(535, 119, 67, 20);
		contentPane.add(lbl_Author);
		
		txtTitle = new JTextField();
		txtTitle.setColumns(10);
		txtTitle.setBounds(570, 88, 86, 20);
		contentPane.add(txtTitle);
		
		JLabel lbl_Title = new JLabel("Titol:");
		lbl_Title.setBounds(535, 88, 67, 20);
		contentPane.add(lbl_Title);
		
		txtId = new JTextField();
		txtId.setColumns(10);
		txtId.setBounds(570, 59, 86, 20);
		contentPane.add(txtId);
		
		JLabel lbl_Id = new JLabel("ID:");
		lbl_Id.setBounds(535, 59, 67, 20);
		contentPane.add(lbl_Id);
		
		txtNumPag = new JTextField();
		txtNumPag.setColumns(10);
		txtNumPag.setBounds(658, 241, 86, 20);
		contentPane.add(txtNumPag);
		
		JLabel lbl_NumPag = new JLabel("Numero de paginas: ");
		lbl_NumPag.setBounds(535, 241, 121, 20);
		contentPane.add(lbl_NumPag);
		
		btnCrear = new JButton("Mandar");
		btnCrear.setBounds(533, 272, 89, 23);
		contentPane.add(btnCrear);
		this.setVisible(true);
	}

	public JPanel getContentPane() {
		return contentPane;
	}

	public JTextField getTxtAnyNax() {
		return txtAnyNax;
	}

	public JTextField getTxtAnyPub() {
		return txtAnyPub;
	}

	public JTextField getTxtEditorial() {
		return txtEditorial;
	}

	public JTextField getTxtAuthor() {
		return txtAuthor;
	}

	public JTextField getTxtTitle() {
		return txtTitle;
	}

	public JTextField getTxtId() {
		return txtId;
	}

	public JTextField getTxtNumPag() {
		return txtNumPag;
	}
	
	public JButton getBtnCrear() {
		return btnCrear;
	}
}
