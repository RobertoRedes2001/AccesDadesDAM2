package es.florida.aev3;

import es.florida.aev3.Controlador;
import es.florida.aev3.Modelo;
import es.florida.aev3.Vista;

public class Principal {
	public static void main(String[] args) {
		
		Modelo modelo = new Modelo();
		Vista vista = new Vista();
		Controlador cont = new Controlador(modelo, vista);
		
	}
}
