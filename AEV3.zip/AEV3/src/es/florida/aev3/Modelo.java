package es.florida.aev3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.bson.Document;
import org.json.JSONObject;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Modelo {
	
	private MongoClient mongoClient;
	private MongoDatabase database;
	private static MongoCollection<Document> coleccionBooks;
	private static MongoCollection<Document> coleccionUsers;
	
	public Modelo() {
		File archivo = new File("conexionDDBB.json");
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			String conexion = br.readLine();
			br.close();
			fr.close();
			JSONObject obj = new JSONObject(conexion);
			mongoClient = new MongoClient(obj.getString("Cliente"), obj.getInt("Puerto"));
			database = mongoClient.getDatabase(obj.getString("Database"));
			coleccionBooks = database.getCollection(obj.getString("Coleccion1"));
			coleccionUsers = database.getCollection(obj.getString("Coleccion2"));
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public static String codificarPass(String password) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-256");
		} 
		catch (NoSuchAlgorithmException e) {		
			e.printStackTrace();
			return null;
		}
		byte[] hash = md.digest(password.getBytes());
		StringBuffer sb = new StringBuffer();
		for(byte b : hash) {        
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	public static void crearBook(int id, String title, String autor, int any, int nax, String editorial, int pags, String img) {
		Document doc = new Document();
		doc.append("Id", id);
		doc.append("Titulo", title);
		doc.append("Autor", autor);
		doc.append("Anyo_nacimiento", nax);
		doc.append("Anyo_publicacion", any);
		doc.append("Editorial", editorial);
		doc.append("Numero_paginas", pags);
		doc.append("Thumbnail", img);
		coleccionBooks.insertOne(doc);
	}
	
	
}
