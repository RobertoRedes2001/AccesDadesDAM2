package es.florida.aev2;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Modelo modelo = new Modelo();
		Vista vista = new Vista();
		Controlador cont = new Controlador(modelo, vista);
		
	}

}
